import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class EcoStyle {
  static const boldStyle = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: Colors.black,
  );
}
