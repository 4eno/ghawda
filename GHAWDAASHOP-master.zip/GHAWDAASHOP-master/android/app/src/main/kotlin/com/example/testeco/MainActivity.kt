package com.example.testeco

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
